package com.kks.Project.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.kks.Project.entity.Author;
import com.kks.Project.entity.Publisher;
import com.kks.Project.repository.AuthorRepo;
import com.kks.Project.repository.PublisherRepo;

@Service
public class PublisherService {
	@Autowired
	private PublisherRepo publisherRepo;

	// Method to retrieve all publishers
	@Transactional(readOnly=true)
	public List<Publisher> getAllPublishers()
	{
		return publisherRepo.findAll();
	}
	
	// Method to retrieve a publisher by its publisherId
	@Transactional(readOnly=true)
	public Publisher getPublisherByPublisherId(int publisherId)
	{
		Optional<Publisher> ot = publisherRepo.findById(publisherId);
		if(ot.isPresent())
			return ot.get();
		return new Publisher(); // Return an empty Publisher object if not found
	}
	
	// Method to insert or modify a publisher
	@Transactional
	public boolean insertOrModifyPublisher(Publisher publisher)
	{
		if(publisherRepo.save(publisher) == null)
			return false;
		return true;
	}
	
	// Method to delete a publisher by its publisherId
	@Transactional
	public boolean deletePublisherByPublisherId(int publisherId)
	{
		long count = publisherRepo.count(); // Get the count of publishers before deletion
		publisherRepo.deleteById(publisherId);
		if(count > publisherRepo.count()) // Check if the count decreased after deletion
			return true;
		return false;
	}
}
