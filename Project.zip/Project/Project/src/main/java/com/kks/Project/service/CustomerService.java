package com.kks.Project.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.kks.Project.entity.Customer;
import com.kks.Project.repository.CustomerRepo;

@Service
public class CustomerService {
	@Autowired
	private CustomerRepo customerRepo;

	// Method to retrieve all customers
	@Transactional(readOnly=true)
	public List<Customer> getAllCustomers()
	{
		return customerRepo.findAll();
	}
	
	// Method to retrieve a customer by their customerId
	@Transactional(readOnly=true)
	public Customer getCustomerByCustomerId(int customerId)
	{
		Optional<Customer> ot = customerRepo.findById(customerId);
		if(ot.isPresent())
			return ot.get();
		return new Customer(); // Return an empty Customer object if not found
	}
	
	// Method to insert or modify a customer
	@Transactional
	public boolean insertOrModifyCustomer(Customer customer)
	{
		if(customerRepo.save(customer) == null)
			return false;
		return true;
	}
	
	// Method to delete a customer by their customerId
	@Transactional
	public boolean deleteCustomerByCustomerId(int customerId)
	{
		long count = customerRepo.count(); // Get the count of customers before deletion
		customerRepo.deleteById(customerId);
		if(count > customerRepo.count()) // Check if the count decreased after deletion
			return true;
		return false;
	}
	
	// Method to count customers with a given email and password
	@Transactional
	public Integer countOfCustomer(String email, String password) {
		Customer c = customerRepo.findCustomerIdByEmailAndPassword(email, password);
		if(c != null) {
			return c.getCustomerID();
		}
		else
			return null; 
	}
}
