package com.kks.Project.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;


import com.kks.Project.entity.Customer;
import com.kks.Project.entity.Orders;

public interface OrdersRepo extends JpaRepository<Orders, Integer>{

	List<Orders> findByCustId( Customer custId);

//	List<Orders> findByCustomerId(Customer customer);
}
