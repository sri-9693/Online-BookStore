package com.kks.Project.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.kks.Project.entity.Payment;
import com.kks.Project.repository.PaymentRepo;

@Service
public class PaymentService {
	@Autowired
	private PaymentRepo paymentRepo;

	// Method to retrieve payments for a specific customer
	@Transactional(readOnly=true)
	public Optional<Payment> getAllPayments(int customerId)
	{
		return paymentRepo.getPayment(customerId);
	}
	
	// Method to retrieve a payment by its paymentId
	@Transactional(readOnly=true)
	public Payment getPaymentByPaymentId(int paymentId)
	{
		Optional<Payment> ot = paymentRepo.findById(paymentId);
		if(ot.isPresent())
			return ot.get();
		return new Payment(); // Return an empty Payment object if not found
	}
	
	// Method to insert or modify a payment
	@Transactional
	public boolean insertOrModifyPayment(Payment payment)
	{
		if(paymentRepo.save(payment) == null)
			return false;
		return true;
	}
	
	// Method to delete a payment by its paymentId
	@Transactional
	public boolean deletePaymentByPaymentId(int paymentId)
	{
		long count = paymentRepo.count(); // Get the count of payments before deletion
		paymentRepo.deleteById(paymentId);
		if(count > paymentRepo.count()) // Check if the count decreased after deletion
			return true;
		return false;
	}
	
	// Method to make a payment for a customer with an optional coupon code
	@Transactional
	public void makingPayment(int customerId, double amount, String couponCode) {
		paymentRepo.makePayment(customerId, amount, couponCode);
	}
}
