package com.kks.Project.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.kks.Project.entity.Author;
import com.kks.Project.entity.Book;
import com.kks.Project.repository.AuthorRepo;
import com.kks.Project.repository.BookRepo;

@Service
public class BookService {
	@Autowired
	private BookRepo bookRepo;

	// Method to retrieve all books
	@Transactional(readOnly=true)
	public List<Book> getAllBooks()
	{
		return bookRepo.findAll();
	}
	
	// Method to retrieve a book by its bookId
	@Transactional(readOnly=true)
	public Book getBookByBookId(int bookId)
	{
		Optional<Book> ot = bookRepo.findById(bookId);
		if(ot.isPresent())
			return ot.get();
		return new Book(); // Return an empty Book object if not found
	}
	
	// Method to insert or modify a book
	@Transactional
	public boolean insertOrModifyBook(Book book)
	{
		if(bookRepo.save(book) == null)
			return false;
		return true;
	}
	
	// Method to delete a book by its bookId
	@Transactional
	public boolean deleteBookByBookId(int bookId)
	{
		long count = bookRepo.count(); // Get the count of books before deletion
		bookRepo.deleteById(bookId);
		if(count > bookRepo.count()) // Check if the count decreased after deletion
			return true;
		return false;
	}
	
	// Method to find a book by its title
	@Transactional
	public Optional<Book> findingByTitle(String title)
	{
		return bookRepo.findByTitle(title);
	}
	
	// Method to search for books by category and name
	@Transactional
	public List<Book> searchBooksBy(String name) {
		return bookRepo.searchBook(name + "%");
	}
}
