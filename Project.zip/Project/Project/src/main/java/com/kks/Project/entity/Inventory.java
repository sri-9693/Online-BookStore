package com.kks.Project.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;

@Entity// Entity annotation indicates that this class represents an entity in the database
public class Inventory {
	@Id  // Id annotation specifies that this field is the primary key
	@GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="inventory_id")  // Specifies the column name in the database
	private int inventoryID;

	//Joining columns with relationships
	@OneToOne()
    @JoinColumn(name="book_id")
    private Book bookId;

	private int quantity;

    
	// Default constructor
    public Inventory() {}

    // Parameterized constructor
	public Inventory(int inventoryID, Book bookId, int quantity) {
		super();
		this.inventoryID = inventoryID;
		this.bookId = bookId;
		this.quantity = quantity;
	}


	// Getter and setter methods for accessing and modifying private fields
	public int getInventoryID() {
		return inventoryID;
	}



	public void setInventoryID(int inventoryID) {
		this.inventoryID = inventoryID;
	}



	public Book getBookId() {
		return bookId;
	}



	public void setBookId(Book bookId) {
		this.bookId = bookId;
	}



	public int getQuantity() {
		return quantity;
	}



	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

    
}
