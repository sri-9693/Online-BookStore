package com.kks.Project.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.kks.Project.entity.Cart;
import com.kks.Project.entity.Customer;
import com.kks.Project.entity.Orders;
import com.kks.Project.repository.OrdersRepo;

@Service
public class OrdersService {
	@Autowired
	private OrdersRepo ordersRepo;

	// Method to retrieve all orders
	@Transactional(readOnly=true)
	public List<Orders> getAllOrderss()
	{
		return ordersRepo.findAll();
	}
	
	// Method to retrieve orders by customer
	@Transactional(readOnly=true)
	public List<Orders> getBooksByCustomrId(Customer customer)
	{
		return ordersRepo.findByCustId(customer);
	}
	
	// Method to retrieve an order by its ordersId
	@Transactional(readOnly=true)
	public Orders getOrdersByOrdersId(int ordersId)
	{
		Optional<Orders> ot = ordersRepo.findById(ordersId);
		if(ot.isPresent())
			return ot.get();
		return new Orders(); // Return an empty Orders object if not found
	}
	
	// Method to insert or modify an order
	@Transactional
	public boolean insertOrModifyOrders(Orders orders)
	{
		if(ordersRepo.save(orders) == null)
			return false;
		return true;
	}
	
	// Method to delete an order by its ordersId
	@Transactional
	public boolean deleteOrdersByOrdersId(int ordersId)
	{
		long count = ordersRepo.count(); // Get the count of orders before deletion
		ordersRepo.deleteById(ordersId);
		if(count > ordersRepo.count()) // Check if the count decreased after deletion
			return true;
		return false;
	}
}
