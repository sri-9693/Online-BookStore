package com.kks.Project.entity;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity  // Entity annotation indicates that this class represents an entity in the database
public class Author 
{
	@Id  // Id annotation specifies that this field is the primary key
	@GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="author_id")  // Specifies the column name in the database
    private int authorID;
	
    @Column(name="author_name")
    private String authorName;
    
 // Default constructor
    public Author() {}
    
 // Parameterized constructor
	public Author(int authorID, String authorName) {
		super();
		this.authorID = authorID;
		this.authorName = authorName;
	}
	
	// Getter and setter methods for accessing and modifying private fields
	public int getAuthorID() {
		return authorID;
	}
	public void setAuthorID(int authorID) {
		this.authorID = authorID;
	}
	public String getAuthorName() {
		return authorName;
	}
	public void setAuthorName(String authorName) {
		this.authorName = authorName;
	}

}
