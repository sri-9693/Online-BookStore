package com.kks.Project.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.kks.Project.entity.Coupon;
import com.kks.Project.repository.CouponRepo;

@Service
public class CouponService {
	@Autowired
	private CouponRepo couponRepo;

	// Method to retrieve all coupons
	@Transactional(readOnly=true)
	public List<Coupon> getAllCoupons()
	{
		return couponRepo.findAll();
	}
	
	// Method to retrieve a coupon by its couponId
	@Transactional(readOnly=true)
	public Coupon getCouponByCouponId(int couponId)
	{
		Optional<Coupon> ot = couponRepo.findById(couponId);
		if(ot.isPresent())
			return ot.get();
		return new Coupon(); // Return an empty Coupon object if not found
	}
	
	// Method to insert or modify a coupon
	@Transactional
	public boolean insertOrModifyCoupon(Coupon coupon)
	{
		if(couponRepo.save(coupon) == null)
			return false;
		return true;
	}
	
	// Method to delete a coupon by its couponId
	@Transactional
	public boolean deleteCouponByCouponId(int couponId)
	{
		long count = couponRepo.count(); // Get the count of coupons before deletion
		couponRepo.deleteById(couponId);
		if(count > couponRepo.count()) // Check if the count decreased after deletion
			return true;
		return false;
	}
	
	// Method to retrieve a coupon by its couponCode
	@Transactional
	public Coupon getCouponByCouponCode(String couponCode) {
		return couponRepo.findByCouponCode(couponCode);
	}
}
