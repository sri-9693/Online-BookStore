package com.kks.Project.entity;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

@Entity // Entity annotation indicates that this class represents an entity in the database
public class Book {
	@Id  // Id annotation specifies that this field is the primary key
    @Column(name="book_id") // Specifies the column name in the database
	@GeneratedValue(strategy = GenerationType.IDENTITY)
    private int bookID;
	
    //Joining columns with relationships
    @ManyToOne()
    @JoinColumn(name="author_id")
    private Author authorId;   

    @ManyToOne()
    @JoinColumn(name="publisher_id")
    private Publisher publisherId;

    private String title;

    private String category;

    private double price;

    private String link;

    
 // Default constructor
    public Book() {}

 // Parameterized constructor
	public Book(int bookID, Author authorId, Publisher publisherId, String title, String category, double price,
		String link) {
		super();
		this.bookID = bookID;
		this.authorId = authorId;
		this.publisherId = publisherId;
		this.title = title;
		this.category = category;
		this.price = price;
		this.link = link;
	}

	
	// Getter and setter methods for accessing and modifying private fields
	public String getLink() {
		return link;
	}


	public void setLink(String link) {
		this.link = link;
	}


	public int getBookID() {
		return bookID;
	}

	public void setBookID(int bookID) {
		this.bookID = bookID;
	}

	public Author getAuthorId() {
		return authorId;
	}

	public void setAuthorId(Author authorId) {
		this.authorId = authorId;
	}

	public Publisher getPublisherId() {
		return publisherId;
	}

	public void setPublisherId(Publisher publisherId) {
		this.publisherId = publisherId;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

}
