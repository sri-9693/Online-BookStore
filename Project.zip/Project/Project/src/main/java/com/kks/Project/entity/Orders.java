package com.kks.Project.entity;
import java.time.LocalDateTime;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

@Entity   // Entity annotation indicates that this class represents an entity in the database
public class Orders {
	@Id  // Id annotation specifies that this field is the primary key
    @Column(name="order_id")  // Specifies the column name in the database
	@GeneratedValue(strategy = GenerationType.IDENTITY)
    private int orderID;
	
	//Joining columns with relationships
	@ManyToOne()
	@JoinColumn (name="cust_id")
    private Customer custId;
	
	@Column(name="total_amount")
    private double totalAmount;
	
	@Column(name="order_date")
    private LocalDateTime orderDate;

	 // Default constructor
    public Orders() {}

 // Parameterized constructor
	public Orders(int orderID, Customer custId, double totalAmount, LocalDateTime orderDate) {
		super();
		this.orderID = orderID;
		this.custId = custId;
		this.totalAmount = totalAmount;
		this.orderDate = orderDate;
	}
	
	// Getter and setter methods for accessing and modifying private fields
	public int getOrderID() {
		return orderID;
	}

	public void setOrderID(int orderID) {
		this.orderID = orderID;
	}

	public Customer getCustId() {
		return custId;
	}

	public void setCustId(Customer custId) {
		this.custId = custId;
	}

	public double getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(double totalAmount) {
		this.totalAmount = totalAmount;
	}

	public LocalDateTime getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(LocalDateTime orderDate) {
		this.orderDate = orderDate;
	}

}
