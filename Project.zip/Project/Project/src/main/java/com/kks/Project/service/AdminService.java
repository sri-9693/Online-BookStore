package com.kks.Project.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.kks.Project.entity.Admin;
import com.kks.Project.entity.PopularBooks;
import com.kks.Project.repository.AdminRepo;
import com.kks.Project.repository.PopularBooksRepo;

@Service
public class AdminService {
	@Autowired
	private AdminRepo adminRepo;
	
	@Autowired
	PopularBooksRepo popularBooksRepo;

	// Method to retrieve all admins
	@Transactional(readOnly=true)
	public List<Admin> getAllAdmins()
	{
		return adminRepo.findAll();
	}
	
	// Method to retrieve an admin by their adminId
	@Transactional(readOnly=true)
	public Admin getAdminByAdminId(int adminId)
	{
		Optional<Admin> ot = adminRepo.findById(adminId);
		if(ot.isPresent())
			return ot.get();
		return new Admin(); // Return an empty Admin object if not found
	}
	
	// Method to insert or modify an admin
	@Transactional
	public boolean insertOrModifyAdmin(Admin admin)
	{
		if(adminRepo.save(admin) == null)
			return false;
		return true;
	}
	
	// Method to delete an admin by their adminId
	@Transactional
	public boolean deleteAdminByAdminId(int adminId)
	{
		long count = adminRepo.count(); // Get the count of admins before deletion
		adminRepo.deleteById(adminId);
		if(count > adminRepo.count()) // Check if the count decreased after deletion
			return true;
		return false;
	}
	
	// Method to count admins with a given email and password
	@Transactional
	public Integer countOfAdmin(String email, String password) {
		Admin a = adminRepo.findAdminIdByEmailAndPassword(email, password);
		if(a != null) {
			return a.getAdminId();
		}
		else
			return null; // Return null if no admin is found with the given credentials
	}
	
	// Method to retrieve popular books
	@Transactional(readOnly=true)
	public List<PopularBooks> getPopularBooks()
	{
		 adminRepo.popularBook(); 
		 return popularBooksRepo.findAll(); // Retrieve and return all popular books
	}
}
