package com.kks.Project.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

@Entity   // Entity annotation indicates that this class represents an entity in the database
public class PopularBooks 
{
	@Id  // Id annotation specifies that this field is the primary key
	@Column(name="p_id")  // Specifies the column name in the database
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int popularId;
	
	//Joining columns with relationships
	@ManyToOne()
	@JoinColumn(name="book_id")
	private Book bookId;
	
	private int quantity;
	
	@Column(name="total_spent")
	private double totalSpent;
	
	// Default constructor
	public PopularBooks () {}

	// Parameterized constructor
	public PopularBooks(int popularId, Book bookId, int quantity, double totalSpent) 
	{
		this.popularId = popularId;
		this.bookId = bookId;
		this.quantity = quantity;
		this.totalSpent = totalSpent;
	}

	// Getter and setter methods for accessing and modifying private fields
	public int getPopularId() {
		return popularId;
	}

	public void setPopularId(int popularId) {
		this.popularId = popularId;
	}

	public Book getBookId() {
		return bookId;
	}

	public void setBookId(Book bookId) {
		this.bookId = bookId;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public double getTotalSpent() {
		return totalSpent;
	}

	public void setTotalSpent(double totalSpent) {
		this.totalSpent = totalSpent;
	}
}
