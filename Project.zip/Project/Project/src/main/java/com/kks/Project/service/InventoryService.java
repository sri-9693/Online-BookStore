package com.kks.Project.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.kks.Project.entity.Book;
import com.kks.Project.entity.Inventory;
import com.kks.Project.repository.InventoryRepo;

@Service
public class InventoryService {
	@Autowired
	private InventoryRepo inventoryRepo;

	// Method to retrieve all inventory records
	@Transactional(readOnly=true)
	public List<Inventory> getAllInventorys()
	{
		return inventoryRepo.findAll();
	}
	
	// Method to retrieve an inventory record by its inventoryId
	@Transactional(readOnly=true)
	public Inventory getInventoryByInventoryId(int inventoryId)
	{
		Optional<Inventory> ot = inventoryRepo.findById(inventoryId);
		if(ot.isPresent())
			return ot.get();
		return new Inventory(); // Return an empty Inventory object if not found
	}
	
	// Method to insert or modify an inventory record
	@Transactional
	public boolean insertOrModifyInventory(Inventory inventory)
	{
		if(inventoryRepo.save(inventory) == null)
			return false;
		return true;
	}
	
	// Method to delete an inventory record by its inventoryId
	@Transactional
	public boolean deleteInventoryByInventoryId(int inventoryId)
	{
		long count = inventoryRepo.count(); // Get the count of inventory records before deletion
		inventoryRepo.deleteById(inventoryId);
		if(count > inventoryRepo.count()) // Check if the count decreased after deletion
			return true;
		return false;
	}
	
	// Method to retrieve an inventory record by its associated book
	@Transactional
	public Inventory getByBookId(Book bookId) {
		return inventoryRepo.findByBookId(bookId);
	}
}
