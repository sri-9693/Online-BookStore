package com.kks.projectk.repository;

// Import statements for required classes and packages
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;

import com.kks.projectk.entity.Customer;
import com.kks.projectk.entity.Orders;


public interface OrdersRepo extends JpaRepository<Orders, Integer> {
    
    // method to find orders by customer ID
    List<Orders> findByCustId(Customer custId);
}
