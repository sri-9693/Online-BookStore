// Import statements for required classes and packages
package com.kks.projectk.service;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.kks.projectk.entity.Cart;
import com.kks.projectk.entity.Customer;
import com.kks.projectk.repository.CartRepo;

@Service
public class CartService {
    // Autowiring the CartRepo bean
    @Autowired
    private CartRepo cartRepo;

    // Transactional method to retrieve a list of all carts (read-only)
    @Transactional(readOnly = true)
    public List<Cart> getAllCarts() {
        return cartRepo.findAll();
    }

    // Transactional method to retrieve a list of books in a customer's cart
    @Transactional(readOnly = true)
    public List<Cart> getBooksByCustomrId(Customer customer) {
        // Using the findByCustomerId method of the CartRepo to retrieve books in the customer's cart
        return cartRepo.findByCustomerId(customer);
    }

    // Transactional method to retrieve a cart by cartId (read-only)
    @Transactional(readOnly = true)
    public Cart getCartByCartId(int cartId) {
        Optional<Cart> ot = cartRepo.findById(cartId);
        if (ot.isPresent())
            return ot.get();
        return new Cart();
    }

    // Transactional method to insert or modify a cart
    @Transactional
    public boolean insertOrModifyCart(Cart cart) {
        if (cartRepo.save(cart) == null)
            return false;
        return true;
    }

    // Transactional method to delete a cart by cartId
    @Transactional
    public boolean deleteCartByCartId(int cartId) {
        long count = cartRepo.count();
        cartRepo.deleteById(cartId);
        if (count > cartRepo.count())
            return true;
        return false;
    }

    // Transactional method to increase the quantity of a book in the cart
    @Transactional
    public void increaseQuantity(int cartId, int bookId) {
        cartRepo.increaseQuantity(cartId, bookId);
    }

    // Transactional method to decrease the quantity of a book in the cart
    @Transactional
    public void decreaseQuantity(int cartId, int bookId) {
        cartRepo.decreaseQuantity(cartId, bookId);
    }
}
