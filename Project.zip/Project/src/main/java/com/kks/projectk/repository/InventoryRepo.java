package com.kks.projectk.repository;

// Import statements for required classes and packages
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.query.Procedure;
import org.springframework.data.repository.query.Param;

import com.kks.projectk.entity.Book;
import com.kks.projectk.entity.Inventory;


public interface InventoryRepo extends JpaRepository<Inventory, Integer> {

    //  method to find inventory by associated book
    Inventory findByBookId(Book bookId);

    //  method to call a stored procedure named "updateInventory"
    @Procedure("updateInventory")
    void updateInventory(
        @Param("bookId") int bookId,
        @Param("quantity") int quantity
    );

    //  method to call a stored procedure named "getInventoryByBookId"
    @Procedure("getInventoryByBookId")
    Optional<Inventory> getInventoryByBookId(
        @Param("bookId") int bookId
    );
}
