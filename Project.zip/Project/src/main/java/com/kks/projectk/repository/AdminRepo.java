package com.kks.projectk.repository;

// Import statements for required classes and packages
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.query.Procedure;

import com.kks.projectk.entity.Admin;


public interface AdminRepo extends JpaRepository<Admin, Integer> {
    // method to find an Admin entity by email and password
    Admin findAdminIdByEmailAndPassword(String email, String password);

    //  method using a stored procedure named "popular_book"
    @Procedure("popular_book")
    void popularBook();
}
