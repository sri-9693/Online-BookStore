package com.kks.projectk.repository;

// Import statements for required classes and packages
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.kks.projectk.entity.Book;


public interface BookRepo extends JpaRepository<Book, Integer> {
    //  method to find a book by its title
    Optional<Book> findByTitle(String title);
    
    //  method to search for books by name (title or category)
    @Query("SELECT b FROM Book b WHERE b.title LIKE :name OR b.category LIKE :name")
    List<Book> searchBook(@Param("name") String name);
}
