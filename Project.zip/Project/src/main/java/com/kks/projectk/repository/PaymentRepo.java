package com.kks.projectk.repository;

// Import statements for required classes and packages
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.query.Procedure;
import org.springframework.data.repository.query.Param;

import com.kks.projectk.entity.Payment;


public interface PaymentRepo extends JpaRepository<Payment, Integer> {

    //method to call a stored procedure named "makePayment"
    @Procedure("makePayment")
    void makePayment(
        @Param("customerId") int customerId,
        @Param("ammount") double amount,
        @Param("couponCode") String couponCode
    );

    // method to call a stored procedure named "get_payment"
    @Procedure("get_payment")
    Optional<Payment> getPayment(
        @Param("customerId") int customerId
    );
}
