package com.kks.projectk.controller;

import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.kks.projectk.entity.Payment;
import com.kks.projectk.service.PaymentService;

import jakarta.servlet.http.HttpSession;

@CrossOrigin(origins = {"http://localhost:4200"}, allowCredentials = "true")
@RestController
@RequestMapping("/payment")
public class PaymentController {
    
    @Autowired
    private PaymentService paymentService;
    
    // Handle GET request to retrieve payments for the logged-in customer
    @GetMapping
    public ResponseEntity<Optional<Payment>> getAllPayments(HttpSession session) {
        Optional<Payment> paymentList = null;
        if (session.getAttribute("id") != null) {
            paymentList = paymentService.getAllPayments((int)session.getAttribute("id"));
            if (paymentList.isPresent())
                return new ResponseEntity<Optional<Payment>>(paymentList, HttpStatus.OK);
        }
        return new ResponseEntity<Optional<Payment>>(paymentList, HttpStatus.NOT_FOUND);
    }

    // Handle GET request to retrieve a payment by paymentId
    @GetMapping(value="/{paymentId}", produces="application/json")
    public ResponseEntity<Payment> getPaymentByPaymentId(@PathVariable int paymentId) {
        Payment payment = paymentService.getPaymentByPaymentId(paymentId);
        if (payment != null)
            return new ResponseEntity<Payment>(payment, HttpStatus.OK);
        return new ResponseEntity<Payment>(payment, HttpStatus.NOT_FOUND);
    }
    
    // Handle POST request to insert a payment
    @PostMapping(value="/", consumes="application/json")
    public HttpStatus insertPayment(@RequestBody Payment payment) {
        paymentService.insertOrModifyPayment(payment);
        return HttpStatus.OK;
    }
    
    // Handle PUT request to modify a payment
    @PutMapping(value="/", consumes="application/json")
    public HttpStatus modifyPayment(@RequestBody Payment payment) {
        paymentService.insertOrModifyPayment(payment);
        return HttpStatus.OK;
    }
    
    // Handle DELETE request to delete a payment by paymentId
    @DeleteMapping("/{paymentId}")
    public HttpStatus deletePayment(@PathVariable int paymentId) {
        if (paymentService.deletePaymentByPaymentId(paymentId))
            return HttpStatus.OK;
        return HttpStatus.NOT_FOUND;
    }
    
    // Handle GET request to make a payment with coupon code and amount
    @GetMapping("/makepayment/{couponCode}/{amount}")
    public void makePayment(@PathVariable String couponCode, @PathVariable double amount, HttpSession session) {
        System.out.println(session.getAttribute("id") + " " + couponCode + " " + amount);
        if (session.getAttribute("id") != null) {
            paymentService.makingPayment((int)session.getAttribute("id"), amount, couponCode);
        }
    }
}
