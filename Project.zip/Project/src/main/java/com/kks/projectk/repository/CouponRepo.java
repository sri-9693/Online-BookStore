package com.kks.projectk.repository;

// Import statements for required classes and packages
import org.springframework.data.jpa.repository.JpaRepository;

import com.kks.projectk.entity.Coupon;


public interface CouponRepo extends JpaRepository<Coupon, Integer> {
    //  method to find a coupon by its coupon code
    Coupon findByCouponCode(String couponCode);
}
