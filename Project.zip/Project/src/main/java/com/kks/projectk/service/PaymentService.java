// Import statements for required classes and packages
package com.kks.projectk.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.kks.projectk.entity.Payment;
import com.kks.projectk.repository.PaymentRepo;

@Service
public class PaymentService {
    // Autowiring the PaymentRepo bean
    @Autowired
    private PaymentRepo paymentRepo;

    // Transactional method to retrieve payments for a specific customer by customerId
    @Transactional(readOnly = true)
    public Optional<Payment> getAllPayments(int customerId) {
        return paymentRepo.getPayment(customerId);
    }

    // Transactional method to retrieve a payment by paymentId (read-only)
    @Transactional(readOnly = true)
    public Payment getPaymentByPaymentId(int paymentId) {
        Optional<Payment> ot = paymentRepo.findById(paymentId);
        if (ot.isPresent())
            return ot.get();
        return new Payment();
    }

    // Transactional method to insert or modify a payment
    @Transactional
    public boolean insertOrModifyPayment(Payment payment) {
        if (paymentRepo.save(payment) == null)
            return false;
        return true;
    }

    // Transactional method to delete a payment by paymentId
    @Transactional
    public boolean deletePaymentByPaymentId(int paymentId) {
        long count = paymentRepo.count();
        paymentRepo.deleteById(paymentId);
        if (count > paymentRepo.count())
            return true;
        return false;
    }

    // Transactional method to make a payment for a customer
    @Transactional
    public void makingPayment(int customerId, double amount, String couponCode) {
        paymentRepo.makePayment(customerId, amount, couponCode);
    }
}
