package com.kks.projectk.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.kks.projectk.entity.Book;
import com.kks.projectk.entity.Cart;
import com.kks.projectk.entity.Customer;
import com.kks.projectk.entity.Inventory;
import com.kks.projectk.service.CartService;
import com.kks.projectk.service.InventoryService;

import jakarta.servlet.http.HttpSession;

@CrossOrigin(origins = {"http://localhost:4200"}, allowCredentials = "true")
@RestController
@RequestMapping("/cart")
public class CartController {
    
    @Autowired
    private CartService cartService;
    
    @Autowired
    private InventoryService inventoryService;
    
    // Handle GET request to retrieve all items in the cart
    @GetMapping
    public ResponseEntity<List<Cart>> getAllCarts() {
        List<Cart> cart = cartService.getAllCarts();
        if (cart.size() != 0)
            return new ResponseEntity<List<Cart>>(cart, HttpStatus.OK);
        return new ResponseEntity<List<Cart>>(cart, HttpStatus.NOT_FOUND);
    }
    
    // Handle GET request to retrieve books in the cart for a specific customer
    @GetMapping("/mybooks")
    public ResponseEntity<List<Cart>> getBooksByCustomrId(HttpSession session) {
        Customer customer = new Customer();
        int id = (int) session.getAttribute("id");
        customer.setCustomerID(id);
        List<Cart> cart = cartService.getBooksByCustomrId(customer);
        if (cart.size() != 0)
            return new ResponseEntity<List<Cart>>(cart, HttpStatus.OK);
        return new ResponseEntity<List<Cart>>(cart, HttpStatus.NOT_FOUND);
    }
    
    // Handle GET request to retrieve a cart item by cartId
    @GetMapping(value="/{cartId}", produces="application/json")
    public ResponseEntity<Cart> getCartByCartId(@PathVariable int cartId) {
        Cart cart = cartService.getCartByCartId(cartId);
        if (cart != null)
            return new ResponseEntity<Cart>(cart, HttpStatus.OK);
        return new ResponseEntity<Cart>(cart, HttpStatus.NOT_FOUND);
    }
    
    // Handle POST request to add a book to the cart
    @PostMapping(value="/", consumes="application/json")
    public HttpStatus insertCart(@RequestBody Cart cart, HttpSession session) {
        Inventory inventoryItem = inventoryService.getByBookId(cart.getBookId());
        if (session.getAttribute("id") != null) {
            if (inventoryItem.getQuantity() > 0) {
                Customer cust = new Customer();
                cust.setCustomerID((int) session.getAttribute("id"));
                cart.setCustomerId(cust);
                
                List<Cart> cartList = cartService.getBooksByCustomrId(cust);
                for (Cart cart1 : cartList) {
                    if (cart1.getBookId().getBookID() == cart.getBookId().getBookID() &&
                        cart1.getCustomerId().getCustomerID() == cart.getCustomerId().getCustomerID()) {
                        return HttpStatus.NOT_MODIFIED;
                    }
                }
                
                cart.setBook_id(cart.getBookId());
                cart.setQuantity(1);
                cartService.insertOrModifyCart(cart);
                inventoryService.updateInventory(cart.getBookId().getBookID(), -1);
                return HttpStatus.OK;
            }
            return HttpStatus.NOT_FOUND;
        }
        return HttpStatus.NOT_MODIFIED;
    }
    
    // Handle PUT request to modify a cart item
    @PutMapping(value="/", consumes="application/json")
    public HttpStatus modifyCart(@RequestBody Cart cart) {
        cartService.insertOrModifyCart(cart);
        return HttpStatus.OK;
    }
    
    // Handle DELETE request to delete a cart item by cartId
    @DeleteMapping("/{cartId}")
    public HttpStatus deletecart(@PathVariable int cartId) {
        if (cartService.deleteCartByCartId(cartId))
            return HttpStatus.OK;
        return HttpStatus.NOT_FOUND;
    }
    
    // Handle GET request to increase the quantity of a cart item
    @GetMapping(value="/increase/{cartId}/{bookId}", produces="application/json")
    public HttpStatus increaseCart(@PathVariable int cartId, @PathVariable int bookId) {
        Cart cart = new Cart();
        Book book = new Book();
        book.setBookID(bookId);
        cart.setBook_id(book);
        Inventory inventoryItem = inventoryService.getByBookId(cart.getBookId());
        if (inventoryItem.getQuantity() > 0) {
            cartService.increaseQuantity(cartId, bookId);
            return HttpStatus.OK;
        } else {
            return HttpStatus.NOT_FOUND;
        }
    }
    
    // Handle GET request to decrease the quantity of a cart item
    @GetMapping(value="/decrease/{cartId}/{bookId}", produces="application/json")
    public HttpStatus decreaseCart(@PathVariable int cartId, @PathVariable int bookId) {
        Cart cart = cartService.getCartByCartId(cartId);
        if (cart.getQuantity() == 1) {
            cartService.deleteCartByCartId(cartId);
            return HttpStatus.NOT_FOUND;
        } else {
            cartService.decreaseQuantity(cartId, bookId);
            return HttpStatus.OK;
        }
    }
}
