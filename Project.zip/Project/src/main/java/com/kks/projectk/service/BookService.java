// Import statements for required classes and packages
package com.kks.projectk.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.kks.projectk.entity.Book;
import com.kks.projectk.repository.BookRepo;

@Service
public class BookService {
    // Autowiring the BookRepo bean
    @Autowired
    private BookRepo bookRepo;

    // Transactional method to retrieve a list of all books (read-only)
    @Transactional(readOnly = true)
    public List<Book> getAllBooks() {
        return bookRepo.findAll();
    }
    
    // Transactional method to retrieve a book by bookId (read-only)
    @Transactional(readOnly = true)
    public Book getBookByBookId(int bookId) {
        Optional<Book> ot = bookRepo.findById(bookId);
        if (ot.isPresent())
            return ot.get();
        return new Book();
    }
    
    // Transactional method to insert or modify a book
    @Transactional
    public boolean insertOrModifyBook(Book book) {
        if (bookRepo.save(book) == null)
            return false;
        return true;
    }
    
    // Transactional method to delete a book by bookId
    @Transactional
    public boolean deleteBookByBookId(int bookId) {
        long count = bookRepo.count();
        bookRepo.deleteById(bookId);
        if (count > bookRepo.count())
            return true;
        return false;
    }
    
    // Transactional method to find a book by title
    @Transactional
    public Optional<Book> findingByTitle(String title) {
        return bookRepo.findByTitle(title);
    }
    
    // Transactional method to search books by name
    @Transactional
    public List<Book> searchBooksBy(String name) {
        return bookRepo.searchBook(name + "%");
    }
}
