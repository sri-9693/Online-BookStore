package com.kks.Project.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.kks.Project.entity.Admin;
import com.kks.Project.entity.PopularBooks;
import com.kks.Project.service.AdminService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

// Enable Cross-Origin Resource Sharing (CORS) for requests from http://localhost:4200
@CrossOrigin(origins = {"http://localhost:4200"}, allowCredentials = "true")
@RestController
@RequestMapping("/admin")
public class AdminController {
    
    // Inject the AdminService using Spring's autowiring
    @Autowired
    private AdminService adminService;
    
    // Handle GET request to retrieve all admins
    @GetMapping
    public ResponseEntity<List<Admin>> getAllAdmins() {
        List<Admin> adminList = adminService.getAllAdmins();
        if (adminList.size() != 0)
            return new ResponseEntity<List<Admin>>(adminList, HttpStatus.OK);
        return new ResponseEntity<List<Admin>>(adminList, HttpStatus.NOT_FOUND);
    }
    
    // Handle GET request to retrieve admin by adminId
    @GetMapping(value="/{adminId}", produces="application/json")
    public ResponseEntity<Admin> getAdminByAdminId(@PathVariable int adminId) {
        Admin admin = adminService.getAdminByAdminId(adminId);
        if (admin != null)
            return new ResponseEntity<Admin>(admin, HttpStatus.OK);
        return new ResponseEntity<Admin>(admin, HttpStatus.NOT_FOUND);
    }
    
    // Handle POST request to insert or modify an admin
    @PostMapping(value="/", consumes="application/json")
    public HttpStatus insertOrModifyAdmin(@RequestBody Admin admin) {
        adminService.insertOrModifyAdmin(admin);
        return HttpStatus.OK;
    }
    
    // Handle PUT request to modify an admin
    @PutMapping(value="/", consumes="application/json")
    public HttpStatus modifyAdmin(@RequestBody Admin admin) {
        adminService.insertOrModifyAdmin(admin);
        return HttpStatus.OK;
    }
    
    // Handle DELETE request to delete an admin by adminId
    @DeleteMapping("/{adminId}")
    public HttpStatus deleteAdmin(@PathVariable int adminId) {
        if (adminService.deleteAdminByAdminId(adminId))
            return HttpStatus.OK;
        return HttpStatus.NOT_FOUND;
    }
    
    // Handle POST request for admin login
    @PostMapping(value="/login", consumes="application/json")
    public boolean countOfValidAdmin(@RequestBody Admin admin, HttpServletRequest request) {
        Integer id = adminService.countOfAdmin(admin.getEmail(), admin.getPassword());
        if (id != null) {
            HttpSession session = request.getSession(true);
            session.setAttribute("id", id);
            System.out.println(session.getAttribute("id"));
        }
        return id != null;
    }

    // Handle POST request to insert an admin
    @PostMapping(value="/signup", consumes="application/json")
    public HttpStatus insertAdmin(@RequestBody Admin admin) {
        adminService.insertOrModifyAdmin(admin);
        return HttpStatus.OK;
    }

    // Handle GET request to log out
    @GetMapping("/logout")
    public String logout(HttpSession session) {
        if (session.getAttribute("id") != null) {
            session.invalidate(); // Invalidate (destroy) the session
        }
        System.out.println(session.getAttribute("id"));
        return "redirect:/login"; // Redirect to the login page or any other appropriate URL
    }

    // Handle GET request to retrieve popular books
    @GetMapping("/popularbooks")
    public List<PopularBooks> getPopularBooks() {
        return adminService.getPopularBooks();
    }
}
