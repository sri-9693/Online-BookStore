package com.kks.Project.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.query.Procedure;
import org.springframework.data.repository.query.Param;

import com.kks.Project.entity.Book;
import com.kks.Project.entity.Inventory;

public interface InventoryRepo extends JpaRepository<Inventory, Integer>{

	Inventory findByBookId(Book bookId); 
	
	@Procedure("updateInventory")
	void updateInventory(
		@Param("bookId") int bookId,
		@Param("quantity") int quantity);
	
	@Procedure("getInventoryByBookId")
	Optional<Inventory> getInventoryByBookId(
		@Param("bookId") int bookId);
	
}
