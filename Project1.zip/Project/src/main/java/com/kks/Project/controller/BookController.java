package com.kks.Project.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.kks.Project.entity.Book;
import com.kks.Project.service.BookService;

@RestController
@RequestMapping("/book")
@CrossOrigin(origins = {"http://localhost:4200"})
public class BookController {

    // Inject the BookService using Spring's autowiring
    @Autowired
    private BookService bookService;
    
    // Handle GET request to retrieve all books
    @GetMapping
    public ResponseEntity<List<Book>> getAllBooks() {
        List<Book> bookList = bookService.getAllBooks();
        if (bookList.size() != 0)
            return new ResponseEntity<List<Book>>(bookList, HttpStatus.OK);
        return new ResponseEntity<List<Book>>(bookList, HttpStatus.NOT_FOUND);
    }

    // Handle GET request to retrieve a book by bookId
    @GetMapping(value="/{bookId}", produces="application/json")
    public ResponseEntity<Book> getBookByBookId(@PathVariable int bookId) {
        Book book = bookService.getBookByBookId(bookId);
        if (book != null)
            return new ResponseEntity<Book>(book, HttpStatus.OK);
        return new ResponseEntity<Book>(book, HttpStatus.NOT_FOUND);
    }
    
    // Handle POST request to insert a book
    @PostMapping(value="/")
    public HttpStatus insertBook(@RequestBody Book book) {
        // Check if a book with the same title already exists
        Optional<Book> newBook = bookService.findingByTitle(book.getTitle());
        if (newBook.isEmpty()) {
            bookService.insertOrModifyBook(book);
            return HttpStatus.OK;
        } else {
            return HttpStatus.NOT_FOUND; // Book with the same title already exists
        }
    }
    
    // Handle PUT request to modify a book
    @PutMapping(value="/")
    public HttpStatus modifyBook(@RequestBody Book book) {
        bookService.insertOrModifyBook(book);
        return HttpStatus.OK;
    }
    
    // Handle DELETE request to delete a book by bookId
    @DeleteMapping("/{bookId}")
    public HttpStatus deleteBook(@PathVariable int bookId) {
        if (bookService.deleteBookByBookId(bookId))
            return HttpStatus.OK;
        return HttpStatus.NOT_FOUND;
    }
    
    // Handle GET request to search for books by name
    @GetMapping(value="/search/{name}")
    public List<Book> searchBooks(@PathVariable String name) {
        return bookService.searchBooksBy(name);
    }
}
