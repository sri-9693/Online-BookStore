package com.kks.Project.repository;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.query.Procedure;
import com.kks.Project.entity.Admin;

public interface AdminRepo extends JpaRepository<Admin, Integer>
{
	Admin findAdminIdByEmailAndPassword(String email, String password);
	
	@Procedure("popular_book")
	void popularBook();
}
